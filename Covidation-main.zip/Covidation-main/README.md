Payment Gateway Integration

COVIDATION

The Sparks Foundation Internship Project: Paymnet Gateway Integration
This project consists of a simple page to donate money to the foundation.
Once the user selects the amount and mode of payment and does the paymnet a reciept is generated and sent to his/her email.

TECHNOLOGY USED:

--> Front-end: HTML, CSS, Bootstrap & Javascript

FLOW OF THE PAGE:

Home > Donate > Enter amount > Select payment mode > Make payment

HOSTING PALTFORM --> GitHub

Website Link: https://mathuraman14.github.io/Covidation/

Youtube Link: https://youtu.be/LnuuWAYIWY4

Contact: https://www.linkedin.com/in/mathuraman14/
